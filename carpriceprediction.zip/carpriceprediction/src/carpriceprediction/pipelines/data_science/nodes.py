"""
This is a boilerplate pipeline 'data_science'
generated using Kedro 0.19.6
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scipy as sp
from autogluon.tabular import TabularDataset, TabularPredictor
from sklearn.model_selection import train_test_split


def split_data(data: pd.DataFrame):
    train, test = train_test_split(data, test_size=0.2)
    train_data = train
    test_data = test
    test_data.drop(columns=['Price'], inplace=True)
    return train_data, test_data


def train_model_with_autoML(train_data: pd.DataFrame):
    predictor = TabularPredictor(label='Price', path='autoML_predictor', problem_type='regression').fit(train_data, presets='medium_quality')
    return predictor


def evaluate_model(autoML_predictor, test_data: pd.DataFrame):
    predictions = autoML_predictor.predict(test_data)
    print(predictions)
    print(autoML_predictor.leaderboard())
