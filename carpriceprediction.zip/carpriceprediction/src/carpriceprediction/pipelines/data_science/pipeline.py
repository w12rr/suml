"""
This is a boilerplate pipeline 'data_science'
generated using Kedro 0.19.6
"""

from kedro.pipeline import Pipeline, node, pipeline

from .nodes import split_data, train_model_with_autoML, evaluate_model


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline([
        node(
            func=split_data,
            inputs="preprocess_car_sale_data",
            outputs=["train_data", "test_data"],
            name="split_data_node",
        ),
        node(
            func=train_model_with_autoML,
            inputs="train_data",
            outputs="autoML_predictor",
            name="train_model_node_autoML",
        ),
        node(
            func=evaluate_model,
            inputs=["autoML_predictor", "test_data"],
            outputs=None,
            name="evaluate_model_node",
        ),
    ])
