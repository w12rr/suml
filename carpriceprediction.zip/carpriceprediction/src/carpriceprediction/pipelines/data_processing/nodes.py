"""
This is a boilerplate pipeline 'data_processing'
generated using Kedro 0.19.6
"""
import pandas as pd


def preprocess_car_sale(car_sale_dataset: pd.DataFrame):

    car_sale_dataset.drop(columns=['Index', 'Offer_publication_date', 'Offer_location', 'Features', 'Origin_country', 'First_owner',
                     'First_registration_date'], inplace=True)

    return car_sale_dataset
